Angle Units
===========

.. autoclass:: coord.AngleUnit
    :members:
    :special-members: __init__
