Angles
======

.. autoclass:: coord.Angle
    :members:
    :special-members: __init__

.. autofunction:: coord._Angle
